
        
          var GetAllTests=function()
          {
	          var tests=new Array();
	          var test;	
	          var ans=new Array();      		
	          var pic=new Array();
        
    
    ans = new Array();
    pic=new Array();  
    
   
      
    
    pic[0]={pic:"content/test1/1_1_7.png",vec4:new Vector4(229,101,490,390)};
         
    
    ans[0]=new CheckedAns("TsNo1om6Nf","",new Vector4(442,328,65,128));
          
    
    ans[1]=new CheckedAns("w0sHuyByXl","",new Vector4(231,113,40,76));
          
    
    ans[2]=new CheckedAns("TjrLVXSfsJ","",new Vector4(351,114,61,83));
          
    
    ans[3]=new CheckedAns("pVmwKDgy16","",new Vector4(491,110,72,59));
          
    
    ans[4]=new CheckedAns("hZ5HwByrGY","",new Vector4(200,254,187,59));
          
    
    ans[5]=new CheckedAns("mlSOX5ixsT","",new Vector4(603,342,40,60));
          
    
    ans[6]=new CheckedAns("5G2r7bkYzk","",new Vector4(338,430,39,50));
   
      test=new CheckedTest(ans,"","Укажите замок автосцепки",new Vector4(30,30,900,55),pic);
      test.correct=new Array( 
        
          "cd9fbc97afd9d5aad01f39258f4cdc4c"   
      );     
    
    tests[0]=test;
  
    ans = new Array();
    pic=new Array();  
    
   
      
    
    pic[0]={pic:"content/test1/1_1_7.png",vec4:new Vector4(198,103,539,397)};
         
    
    ans[0]=new CheckedAns("bb7vV4YecS","",new Vector4(617,350,33,57));
          
    
    ans[1]=new CheckedAns("nUSDSwa71t","",new Vector4(211,120,15,63));
          
    
    ans[2]=new CheckedAns("o35FLHGaUW","",new Vector4(335,123,58,72));
          
    
    ans[3]=new CheckedAns("nuVcP9iWzW","",new Vector4(491,107,80,63));
          
    
    ans[4]=new CheckedAns("rLGiCX7gWf","",new Vector4(180,279,179,68));
          
    
    ans[5]=new CheckedAns("SbQub16MJr","",new Vector4(319,430,37,60));
          
    
    ans[6]=new CheckedAns("TxlLvZ1fEu","",new Vector4(434,334,66,78));
   
      test=new CheckedTest(ans,"","Укажите замкодержатель автосцепки",new Vector4(30,30,900,55),pic);
      test.correct=new Array( 
        
          "da6ca3d335e2f58acc5177e4b3d65bae"   
      );     
    
    tests[1]=test;
  
    ans = new Array();
    pic=new Array();  
    
   
      
    
    pic[0]={pic:"content/test1/plita_a.png",vec4:new Vector4(-56,323,389,225)};
  
   
      
    
    pic[1]={pic:"content/test1/2.jpg",vec4:new Vector4(659,119,287,188)};
  
   
      
    
    pic[2]={pic:"content/test1/1_1_22.jpg",vec4:new Vector4(-11,101,317,222)};
  
   
      
    
    pic[3]={pic:"content/test1/1_1_21.jpg",vec4:new Vector4(684,306,275,188)};
  
   
      
    
    pic[4]={pic:"content/test1/1_1_20.jpg",vec4:new Vector4(340,183,310,216)};
         
    
    ans[0]=new CheckedAns("KlnGsptyFP","",new Vector4(359,239,172,57));
          
    
    ans[1]=new CheckedAns("5mBZsCU3zm","",new Vector4(51,155,110,71));
          
    
    ans[2]=new CheckedAns("he6tNq8cHb","",new Vector4(606,122,278,135));
          
    
    ans[3]=new CheckedAns("06d8ZDWbbO","",new Vector4(7,357,196,146));
          
    
    ans[4]=new CheckedAns("fguAihzxqC","",new Vector4(701,369,154,59));
   
      test=new CheckedTest(ans,"","Укажите тяговый хомут ",new Vector4(43,28,900,55),pic);
      test.correct=new Array( 
        
          "680d9ff121116f55d39b48ebcbeed2cd"   
      );     
    
    tests[2]=test;
  
    ans = new Array();
    pic=new Array();  
    
   
      
    
    pic[0]={pic:"content/test1/plita_a.png",vec4:new Vector4(13,294,279,227)};
  
   
      
    
    pic[1]={pic:"content/test1/2.jpg",vec4:new Vector4(645,102,304,205)};
  
   
      
    
    pic[2]={pic:"content/test1/1_1_22.jpg",vec4:new Vector4(-47,97,348,229)};
  
   
      
    
    pic[3]={pic:"content/test1/1_1_21.jpg",vec4:new Vector4(693,332,287,197)};
  
   
      
    
    pic[4]={pic:"content/test1/1_1_20.jpg",vec4:new Vector4(298,216,324,211)};
         
    
    ans[0]=new CheckedAns("qQ3d1HQu3i","",new Vector4(20,161,138,79));
          
    
    ans[1]=new CheckedAns("YS5IWAAyFy","",new Vector4(323,269,178,57));
          
    
    ans[2]=new CheckedAns("UzHd2Ohkf7","",new Vector4(601,142,282,106));
          
    
    ans[3]=new CheckedAns("bUOHsOEPu8","",new Vector4(21,344,170,143));
          
    
    ans[4]=new CheckedAns("GsqaorhiSH","",new Vector4(709,396,170,67));
   
      test=new CheckedTest(ans,"","Укажите поглощающий аппарат ",new Vector4(30,30,900,55),pic);
      test.correct=new Array( 
        
          "6b8e0855c4bc13f6f6955cdb339c5b62"   
      );     
    
    tests[3]=test;
  
    ans = new Array();
    pic=new Array();  
           
    
    ans[0]=new CheckedAns("Jy40lYelq0","цепь",new Vector4(80,110,700,52));
          
    
    ans[1]=new CheckedAns("vl8BvhdE9x","фиксирующий кронштейн",new Vector4(80,170,700,52));
          
    
    ans[2]=new CheckedAns("jydCIrIoAb","регулировочный болт",new Vector4(80,230,700,52));
          
    
    ans[3]=new CheckedAns("xJkk6nv7pl","замок",new Vector4(80,290,700,52));
          
    
    ans[4]=new CheckedAns("dAkb2bNhSy","центрирующая балочка",new Vector4(80,350,700,52));
          
    
    ans[5]=new CheckedAns("N4ZkThEkc6","поддерживающий кронштейн",new Vector4(80,410,700,52));
   
      test=new CheckedTest(ans,"","Какие из перечисленных деталей не входят в состав расцепного привода? ",new Vector4(30,30,900,55),pic);
      test.correct=new Array( 
        
          "c655cb0e23e1d003c0851d42edf4aea8" ,
          "3ffa1fe9cb60d5835eb2ca211f71dac6"   
      );     
    
    tests[4]=test;
  
    ans = new Array();
    pic=new Array();  
           
    
    ans[0]=new AnswerSeq("DVA07k51t3","5",new Vector4(28,110,700,52));
          
    
    ans[1]=new AnswerSeq("9Dj2Z5Sw5U","87",new Vector4(28,170,700,52));
          
    
    ans[2]=new AnswerSeq("QXrbuz9syu","-2",new Vector4(28,230,700,52));
          
    
    ans[3]=new AnswerSeq("HV7kSjYWk6","0",new Vector4(28,290,700,52));
          
    
    ans[4]=new AnswerSeq("0SCR6kKHx8","11",new Vector4(28,350,700,52));
   
      test=new TestSeq(ans,"","Укажите последовательность цифр в порядке убывания",new Vector4(30,30,900,55),pic);
      test.correct=new Array(
             
          "bd075f65ad528d1e58cf61b1a1662af8" ,       
          "6631ef8928db87b12aa48bb0c9b08af0" ,       
          "80fab68c5ae345fe71d8fa784f6ea76a" ,       
          "355d205ce1728a398b28a4914dd0cc36" ,       
          "e35c5b2683a3cb933f4b19efa77ee5ee" 
      
      );
    
    tests[5]=test;
  
    return tests;
    }

  